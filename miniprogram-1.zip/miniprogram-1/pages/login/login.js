// pages/login/login.js
var app = getApp();
const db = wx.cloud.database()
const {
    formatTime
} = require("../../utils/util.js")
Page({

    /**
     * 页面的初始数据
     */
    data: {
        UserLogin: false,
        userInfo: null,
        Lv: '1'
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        app.isLogin() // 全局变量
        this.setData({
            UserLogin: app.globalData.UserLogin,
            userInfo: app.globalData.userInfo
        })
    },
    
    //获取用户信息
    getUserProfile() {
        let openId = app.globalData.openid
        //console.log('全局的openid', openId)
        wx.getUserProfile({
            desc: '用于完善会员资料', //声明获取用户信息的用途
            success: (res) => {
                //console.log('点击获取用户信息成功', res.userInfo)
                let userInfo = res.userInfo
                db.collection('UserList').where({
                    '_openid': openId
                }).get({
                    success: res => {
                        console.log('根据全局openid查询用户表成功', res.data)
                        if (res.errMsg == "collection.get:ok" && res.data.length == 0) { //length等于0，证明没有该用户，走写入数据库
                            //console.log('走if-1，开始写入数据库')
                            db.collection('UserList') // 把用户信息写入数据库的用户表
                                .add({
                                    data: {
                                        avatarUrl: userInfo.avatarUrl,
                                        nickName: userInfo.nickName,
                                        mamager: false,
                                        vip: false,
                                        Lv: 1,
                                        registerTime: formatTime(new Date())
                                    },
                                    success: res => {
                                        //console.log('写入成功', res.errMsg)
                                        if (res.errMsg == "collection.add:ok") {
                                            wx.setStorageSync('UserInfo', userInfo) //保存用户信息保存到本地缓存
                                            this.setData({
                                                userInfo: userInfo,
                                                UserLogin: true,
                                                Lv: "1"
                                            })
                                            wx.showToast({
                                                title: '恭喜,登录成功',
                                                icon: "success",
                                                duration: 1000,
                                            })
                                        } else {
                                            // 提示网络错误
                                            wx.showToast({
                                                title: '登录失败，请检查网络后重试！',
                                                icon: 'none',
                                                duration: 1000,
                                            })
                                        }
                                    },
                                    fail: err => {
                                        console.log('用户信息写入失败', err)
                                        // 提示网络错误
                                        wx.showToast({
                                            title: '登录失败，请检查网络后重试！',
                                            icon: 'none',
                                            duration: 1000,
                                        })
                                    }
                                })
                        } else {
                            //console.log('走else-1,数据库里已存有用户信息,直接登录，不用写入数据库')
                            wx.setStorageSync('UserInfo', userInfo) //保存用户信息保存到本地缓存
                            this.setData({
                                userInfo: userInfo,
                                UserLogin: true,
                                Lv: res.data[0].Lv
                            })
                            //更新全局状态
                            app.globalData({
                                userInfo: userInfo,
                                UserLogin: true,
                            })
                        }
                    },
                    fail: err => {
                        console.log('根据全局openid查询用户表失败', err)
                        // 提示网络错误
                        wx.showToast({
                            title: '网络错误！获取授权信息失败',
                            icon: 'none',
                            duration: 1000,
                        })
                    }
                })
            },
            fail: err => {
                console.log('用户信息获取失败', err)
                // 提示网络错误
                wx.showToast({
                    title: '网络错误！获取授权信息失败',
                    icon: 'none',
                    duration: 1000,
                })
            }
        })
    },
    // 跳转到我的收藏
    goMycollection() {
        let UserLogin = this.data.UserLogin
        if (UserLogin) {
            wx.navigateTo({
              url: '../collection/collection',
            })
        } else {
            // 提示登录
            wx.showToast({
                title: '你还未登录，请先登录！',
                icon: 'none',
                duration: 1000,
            })
        }
    },

    // 清除数据退出
    exit() {
        let UserLogin = this.data.UserLogin
        if (UserLogin) {
            wx.showToast({
                title: '退出成功',
                icon:'success',
                duration: 1000,
            })
            this.setData({
                UserLogin: false,
            })
            wx.removeStorageSync('UserInfo')
        } else {
            // 提示登录
            wx.showToast({
                title: '你还未登录，请先登录！',
                icon: 'none',
                duration: 1000,
            })
        }
    },
})
