// miniprogram/pages/detail/detail.js
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        score :0,
        userlike:false,
        imgurl1:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl2:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl3:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl4:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl5:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        likeurl:"",
        detailtitle:"",
        detailcontent:"",
        detailpicsrc:"",
        showmodal:false,
        likeidarray:[],
        curid:0,
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        let title=options.title
        let content=options.content
        let picsrc=options.picsrc
        let like=options.like
        console.log(like)
        this.setData({
          curid:parseInt(options.id)
        })
        // console.log(options)
        let likeid=options.likeid
        let likeidarray=likeid.split(',')
        if(likeidarray==[""])
            likeidarray = []
        console.log(likeidarray)
        let likeidarr=[]
        for(var i=0;i<likeidarray.length;i++)
        {
          likeidarr.push(parseInt(likeidarray[i]))
        }
        this.setData({
          likeidarray:likeidarr
        })
        if(likeidarray==[""])
            likeidarray = []
        // console.log("like",likeidarr)
        console.log(like=='true')
        if(like=='true')
        {
            this.userlike = true;
            this.setData({
            likeurl:"https://s1.ax1x.com/2022/06/29/jnou3F.png"
          })
        }
        else
        {
            this.userlike = false;
            this.setData({
            likeurl:"https://s1.ax1x.com/2022/06/29/jno91g.png"
          })
        }
        this.setData({
          detailtitle:title,
          detailcontent:content,
          detailpicsrc:picsrc,
        })
    },
  
    UserLike(){
      //用户点击收藏
      let openid=app.globalData.openid
      console.log("userlike",this.data.userlike)
      if(this.data.userlike)
      {
          this.setData({
              likeurl:"https://s1.ax1x.com/2022/06/29/jno91g.png",
          })
          this.data.userlike = false;
          let idarray=this.data.likeidarray
          let rearray=[]
          for(var i=0;i<idarray.length;i++)
          {
            if(idarray[i]!=this.data.curid)
            {
              rearray.push(idarray[i])
            }
          }
          wx.cloud.database().collection('UserList').where({
            _openid:openid
          }).update({
              data:{
                  likecollection:rearray
              }
          })
      }
      else {
          this.setData({
              likeurl:"https://s1.ax1x.com/2022/06/29/jnou3F.png",
          })
          this.data.userlike = true;
          let idarray=[]
          this.data.likeidarray.push(this.data.curid)
          for(var i = 0; i<this.data.likeidarray.length;i++)
          {
              idarray.push(this.data.likeidarray[i])
          }
          wx.cloud.database().collection('UserList').where({
            _openid:openid
          }).update({
              data:{
                  likecollection:idarray
              }
          })
      }
    },
  
  
    score:function(e){
      console.log(e)
      // console.log(typeof(e.currentTarget.dataset.id))
      this.score = parseInt(e.currentTarget.dataset.id);
      switch(this.score){
          case 5:
              this.setData({
                  imgurl5:"https://s1.ax1x.com/2022/06/29/jnR4kF.png",
                  })
          case 4:
              this.setData({
                  imgurl4:"https://s1.ax1x.com/2022/06/29/jnR4kF.png",
                  })
          case 3:
              this.setData({
                  imgurl3:"https://s1.ax1x.com/2022/06/29/jnR4kF.png",
                  })
          case 2:
              this.setData({
                  imgurl2:"https://s1.ax1x.com/2022/06/29/jnR4kF.png",
                  })
          case 1:
              this.setData({
                  imgurl1:"https://s1.ax1x.com/2022/06/29/jnR4kF.png",
                  })
          default:
              break;
      }
  
    },
    
    cancelfeed(){
      this.setData({
        showmodal:false,
        imgurl1:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl2:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl3:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl4:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl5:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
      })
    },
  
    sendfeed(){
      wx.showToast({
        title: '成功',
        icon:'success'
      })
      this.setData({
        showmodal:false,
        imgurl1:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl2:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl3:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl4:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
        imgurl5:"https://s1.ax1x.com/2022/06/27/jZeIYT.png",
      })
    },
  
    feedback(){
      this.setData({
        showmodal:true
      })
    },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    }
  })