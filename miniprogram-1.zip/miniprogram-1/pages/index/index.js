// miniprogram/pages/index/index.js
var app = getApp();
const db = wx.cloud.database()
const {
  formatTime
} = require("../../utils/util.js")
//引入插件：微信同声传译
const plugin = requirePlugin('WechatSI');
//获取全局唯一的语音识别管理器recordRecoManager
const manager = plugin.getRecordRecognitionManager();
 
Page({

    /**
     * 页面的初始数据
     */
  
    data: {
        //语音
        recordState: false, //录音状态

        UserLogin: false,
        userInfo: null,
        Lv: '1',
        searchword:'',
        none1:'block',
        none2:'none',
        greetings: '早上好，小鹏汽车',
        // searcharray:[
        //   {id:0,title:"小鹏p7智能灯语",content:"小鹏P7长续航670N ，续航670公里，上牌20年9月，实表7.8万公里，个人一手，确保无事故无泡水，公里数真实，新车落地30万，现仅售19.98万，性价比极高#新能源汽车#",picsrc:"https://s1.ax1x.com/2022/06/28/jmkqgJ.png"},
        //   {id:1,title:"小鹏p8智能灯语",content:"小鹏P7长续航670N ，续航670公里，上牌20年9月，实表7.8万公里，个人一手，确保无事故无泡水，公里数真实，新车落地30万，现仅售19.98万，性价比极高#新能源汽车#",picsrc:"https://s1.ax1x.com/2022/06/28/jmkqgJ.png"},
        //   {id:2,title:"小鹏p9智能灯语",content:"小鹏P7长续航670N ，续航670公里，上牌20年9月，实表7.8万公里，个人一手，确保无事故无泡水，公里数真实，新车落地30万，现仅售19.98万，性价比极高#新能源汽车#",picsrc:"https://s1.ax1x.com/2022/06/28/jmkqgJ.png"},
        //   {id:3,title:"小鹏p0智能灯语",content:"小鹏P7长续航670N ，续航670公里，上牌20年9月，实表7.8万公里，个人一手，确保无事故无泡水，公里数真实，新车落地30万，现仅售19.98万，性价比极高#新能源汽车#",picsrc:"https://s1.ax1x.com/2022/06/28/jmkqgJ.png"},
        //   {id:4,title:"小鹏p5智能灯语",content:"小鹏P5长续航670N ，续航670公里，上牌20年9月，实表7.8万公里，个人一手，确保无事故无泡水，公里数真实，新车落地30万，现仅售19.98万，性价比极高#新能源汽车#",picsrc:"https://s1.ax1x.com/2022/06/28/jmkqgJ.png"},
        // ],
        searcharray : [

        ],
        matcharray:[
  
        ],
        likearray:[

        ],
        likearrayid:[

        ]
    },
  
    inputchange:function(e){
      console.log(e.detail)
      this.setData({
        searchword:e.detail.value
      })
    },
  
    choosedetail(e){
      let idx=e.currentTarget.dataset.id
      let curtarget=this.data.searcharray[idx]
      let likeid=this.data.likearrayid
      var like = false;
      console.log(idx)
      console.log(likeid)
      for(var i=0;i<likeid.length;i++)
      {
          if(idx==likeid[i])
          {
            like=true;
          }
      }
      console.log("like",like)
      //传递参数：
      wx.navigateTo({
        url: '../detail/detail?title='+curtarget.title+"&content="+curtarget.content+"&picsrc="+curtarget.picsrc+"&like="+like+"&likeid="+likeid+"&id="+idx,
      })
    },
  
    Login(){
      wx.navigateTo({
        url: '../login/login',
      })
    },
  
    showcollect(){
        var that = this
        setTimeout(() => {
            console.log('aaaa')
          db.collection('data_1').get({
            success: res => {
              console.log(res.data)
              that.setData({
                searcharray: res.data
              })
            }
          })
        }, 5)
        //获取用户喜欢的数组：
      let openid=app.globalData.openid
      wx.cloud.database().collection('UserList')
      .where({
          _openid:openid
      })
      .get().then(res=>{
        console.log("res",res)
        let likeid=res.data[0].likecollection
        this.setData({
          likearrayid:likeid
        })
      // let curword=this.data.searchword
      setTimeout(() => {
          console.log('bbb')
        let array=this.data.likearrayid
        let infoarray=this.data.searcharray
        let resarray=[]
        for(var i=0;i<array.length;i++)
        {
            resarray.push(infoarray[array[i]])
        }
        console.log(resarray)
        this.setData({
          likearray:resarray
        })
        this.setData({
            none1:'none',
            none2:'display'
          })
        //   this.searchcontent()
      }, 100)
    })
      
  
    },
    
    hidecollect(){
      let resarray=[]
  
      this.setData({
          matcharray:resarray
        })
        this.setData({
          none2:'none',
          none1:'display'
        })
    },
    Search(){
      let curword=this.data.searchword
      if (curword == '')
         return;
      curword="../searchResult/searchResult?key="+curword+"&likeid="+this.data.likearrayid
      wx.navigateTo({
        url: curword,
      })
    },
  
    searchcontent(){
      let curword=this.data.searchword
      let array=this.data.searcharray
      let resarray=[]
      console.log(1)
      for(var i=0;i<array.length;i++)
      {
        if(array[i].title.indexOf(curword)!=-1 || array[i].content.indexOf(curword)!=-1)
        {
          resarray.push(array[i])
        }
      }
      this.setData({
        matcharray:resarray
      })
    },
  
  //获取用户信息
  getUserProfile() {
    let openId = app.globalData.openid
    //console.log('全局的openid', openId)
    wx.getUserProfile({
      desc: '用于完善会员资料', //声明获取用户信息的用途
      success: (res) => {
        //console.log('点击获取用户信息成功', res.userInfo)
        let userInfo = res.userInfo
        db.collection('UserList').where({
          '_openid': openId
        }).get({
          success: res => {
            console.log('根据全局openid查询用户表成功', res.data)
            if (res.errMsg == "collection.get:ok" && res.data.length == 0) { //length等于0，证明没有该用户，走写入数据库
              //console.log('走if-1，开始写入数据库')
              db.collection('UserList') // 把用户信息写入数据库的用户表
                .add({
                  data: {
                    avatarUrl: userInfo.avatarUrl,
                    nickName: userInfo.nickName,
                    mamager: false,
                    vip: false,
                    Lv: 1,
                    registerTime: formatTime(new Date())
                  },
                  success: res => {
                    //console.log('写入成功', res.errMsg)
                    if (res.errMsg == "collection.add:ok") {
                      wx.setStorageSync('UserInfo', userInfo) //保存用户信息保存到本地缓存
                      this.setData({
                        userInfo: userInfo,
                        UserLogin: true,
                        Lv: "1"
                      })
                      wx.showToast({
                        title: '恭喜,登录成功',
                        icon: "success",
                        duration: 1000,
                      })
                    } else {
                      // 提示网络错误
                      wx.showToast({
                        title: '登录失败，请检查网络后重试！',
                        icon: 'none',
                        duration: 1000,
                      })
                    }
                  },
                  fail: err => {
                    console.log('用户信息写入失败', err)
                    // 提示网络错误
                    wx.showToast({
                      title: '登录失败，请检查网络后重试！',
                      icon: 'none',
                      duration: 1000,
                    })
                  }
                })
            } else {
              //console.log('走else-1,数据库里已存有用户信息,直接登录，不用写入数据库')
              wx.setStorageSync('UserInfo', userInfo) //保存用户信息保存到本地缓存
              this.setData({
                userInfo: userInfo,
                UserLogin: true,
                Lv: res.data[0].Lv
              })
              //更新全局状态
              app.globalData({
                userInfo: userInfo,
                UserLogin: true,
              })
            }
          },
          fail: err => {
            console.log('根据全局openid查询用户表失败', err)
            // 提示网络错误
            wx.showToast({
              title: '网络错误！获取授权信息失败',
              icon: 'none',
              duration: 1000,
            })
          }
        })
      },
      fail: err => {
        console.log('用户信息获取失败', err)
        // 提示网络错误
        wx.showToast({
          title: '网络错误！获取授权信息失败',
          icon: 'none',
          duration: 1000,
        })
      }
    })
  },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var that = this
        setTimeout(() => {
          db.collection('data_1').get({
            success: res => {
              console.log(res.data)
              that.setData({
                searcharray: res.data
              })
            }
          })
        }, 5)
      //获取用户喜欢的数组：
      let openid=app.globalData.openid
      wx.cloud.database().collection('UserList')
      .where({
          _openid:openid
      })
      .get().then(res=>{
        console.log("res",res)
        let likeid=res.data[0].likecollection
        this.setData({
          likearrayid:likeid
        })
      })

    //识别语音
    this.initRecord();

      var  that = this;
     var timestamp = Date.parse(new Date());
     timestamp = timestamp / 1000;
     // console.log("当前时间戳为：" + timestamp);
  
     //获取当前时间
     var n = timestamp * 1000;
  
     var date = new Date(n);
     //获取时
     var h = date.getHours();
     
    //  console.log("现在的时间是"+h+"点")
  
   
     if (0 < h && h <= 6) {
      
    //    console.log("  0：00—6:00凌晨:勤奋的你")
       that.setData({
         greetings: '凌晨好, 小鹏汽车'
       })
     } else if (6 <= h && h < 11) {
      
    //    console.log("6：00—6:00早上:奋斗的你")
       that.setData({
         greetings: '早上好, 小鹏汽车'
       })
     }
     else if (11 <= h && h <= 13) {
      
    //    console.log("11：00—13:00中午:激情的你")
       that.setData({
         greetings: '中午好, 小鹏汽车'
       })
     } else if (13 <= h && h <= 16) {
     
    //    console.log("18:00—24:00下午:懒洋洋的你")
       that.setData({
         greetings:'下午好, 小鹏汽车'
       })
     }
     else if (16 <= h && h <= 18) {
      
    //    console.log("16：00：00—18:00傍晚:活力的你")
       that.setData({
         greetings: '傍晚好, 小鹏汽车'
       })
     }
     else {
       
        // console.log("晚上啦，记得好好照顾自已，别熬夜")
         that.setData({
             greetings: '晚上好， 小鹏汽车'
       })
     }
  },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        var that = this
        setTimeout(() => {
        //   console.log("1111111111")
        //   console.log(that.data.searcharray)
        //   console.log("1111111111")
        //   this.searchcontent()
        }, 500)
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        app.isLogin() // 全局变量
        this.setData({
          UserLogin: app.globalData.UserLogin,
          userInfo: app.globalData.userInfo
        })
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    },

    //识别语音 -- 初始化
  initRecord: function () {
    const that = this;
    // 有新的识别内容返回，则会调用此事件
    manager.onRecognize = function (res) {
      console.log(res)
    }
    // 正常开始录音识别时会调用此事件
    manager.onStart = function (res) {
      console.log("成功开始录音识别", res)
    }
    // 识别错误事件
    manager.onError = function (res) {
      console.error("error msg", res)
    }
    //识别结束事件
    manager.onStop = function (res) {
      console.log('..............结束录音')
      console.log('录音临时文件地址 -->' + res.tempFilePath); 
      console.log('录音总时长 -->' + res.duration + 'ms'); 
      console.log('文件大小 --> ' + res.fileSize + 'B');
      console.log('语音内容 --> ' + res.result);
      if (res.result == '') {
        wx.showModal({
          title: '提示',
          content: '听不清楚，请重新说一遍！',
          showCancel: false,
          success: function (res) {}
        })
        return;
      }
      var text = that.data.searchword + res.result;
      text=text.slice(0, -1)
      that.setData({
        searchword: text
      })
    }
  },
  //语音  --按住说话
  touchStart: function (e) {
    this.setData({
      recordState: true  //录音状态
    })
    // 语音开始识别
    manager.start({
      lang: 'zh_CN',// 识别的语言，目前支持zh_CN en_US zh_HK sichuanhua
    })
  },
  //语音  --松开结束
  touchEnd: function (e) {
    this.setData({
      recordState: false
    })
    // 语音结束识别
    manager.stop();
  },
  })